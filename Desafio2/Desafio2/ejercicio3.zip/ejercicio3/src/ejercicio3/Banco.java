package ejercicio3;

public class Banco {
	
	private String nombre;
	private Integer codigo;

}
