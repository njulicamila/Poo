package Envases;

public class Interfaz {

	
	public static void main(String[] args) {
        Elemento elem = new Elemento(200, 100, 50, 1000);
	
	elem.setTipo("Botella");

	System.out.println("-------------------------");
	System.out.println("Datos del envase:");
	System.out.println("Peso: " + elem.getPeso());
	System.out.println("Alto: " + elem.getAlto());
	System.out.println("Ancho: " + elem.getAncho());
	System.out.println("Tipo: " + elem.getTipo());
	System.out.println("-------------------------");

    Recibo recibo = new Recibo();
	recibo.setTipo(elem.getTipo());
	recibo.setTotal(200.0);
	recibo.setValor(350.0);
	System.out.println("-------------------------");
    System.out.println("Datos del recibo:");
	System.out.println("Tipo de elemento: " + recibo.getTipo());
	System.out.println("Total: " + recibo.getTotal());
	System.out.println("Valor: " + recibo.getValor());
	System.out.println("-------------------------");
    }
}
