package Envases;

public class Elemento {

	
	private double alto;
	private double ancho;
	private double peso;
	private double cantML;
	private String tipo;
	
	public Elemento(double alto, double ancho, double peso, double cantML) {
		super();
		this.setAlto(alto);
		this.setAncho(ancho);
		this.setPeso(peso);
		this.cantML = cantML;
		this.tipo = this.tipo;
	}

	public String getTipo() {
		return tipo;
	}

	public void setTipo(String tipo) {
		this.tipo = tipo;
	}

	public double getPeso() {
		return peso;
	}

	public void setPeso(double peso) {
		this.peso = peso;
	}

	public double getAlto() {
		return alto;
	}

	public void setAlto(double alto) {
		this.alto = alto;
	}

	public double getAncho() {
		return ancho;
	}

	public void setAncho(double ancho) {
		this.ancho = ancho;
	}
	
	
}
