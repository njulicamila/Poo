package ejercicio3;

import java.util.Date;

public class FondoDeInversion {
 
	private String nombre;
	private double importe;
	private boolean esRentable;
	private Date fApertura;
	private Date fVencimiento;
	public FondoDeInversion(String nombre, boolean esRentable, Date fApertura, Date fVencimiento) {
		super();
		this.nombre = nombre;
		this.esRentable= esRentable;
		this.fApertura = fApertura;
		this.fVencimiento = fVencimiento;
	}
	public String getNombre() {
		return nombre;
	}
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	public double getImporte() {
		return importe;
	}
	public void setImporte(double importe) {
		this.importe = importe;
	}
	public Date getfApertura() {
		return fApertura;
	}
	public void setfApertura(Date fApertura) {
		this.fApertura = fApertura;
	}
	public Date getfVencimiento() {
		return fVencimiento;
	}
	public void setfVencimiento(Date fVencimiento) {
		this.fVencimiento = fVencimiento;
	}
	
	
}
