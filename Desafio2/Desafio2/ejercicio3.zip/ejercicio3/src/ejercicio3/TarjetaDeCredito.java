package ejercicio3;

public class TarjetaDeCredito extends Cuenta {

	private String titular;
	private Integer ID;
	private String fvencimiento;
	private Integer codigo;
	public TarjetaDeCredito(String titular, Integer iD, String fvencimiento, Integer codigo) {
		super();
		this.titular = titular;
		ID = iD;
		this.fvencimiento = fvencimiento;
		this.codigo = codigo;
	}
	public String getTitular() {
		return titular;
	}
	public void setTitular(String titular) {
		this.titular = titular;
	}
	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	public String getFvencimiento() {
		return fvencimiento;
	}
	public void setFvencimiento(String fvencimiento) {
		this.fvencimiento = fvencimiento;
	}
	public Integer getCodigo() {
		return codigo;
	}
	public void setCodigo(Integer codigo) {
		this.codigo = codigo;
	}
	
	
	
}
