package tramitesacademicos;

import java.sql.Date;
import java.util.ArrayList;

public class Interfaz {

	
	public static void main(String[] args) {
		Carrera c= new Carrera("Ingenieria en Sistemas","Palermo");
		ArrayList<AsignaturaCursada> asignaturasCursadas = new ArrayList<AsignaturaCursada>();
		asignaturasCursadas.add(new AsignaturaCursada("Introduccion a la programacion"));
		asignaturasCursadas.add(new AsignaturaCursada("Introduccion a la matematica"));
		asignaturasCursadas.add(new AsignaturaCursada("Programacion I"));
		Alumno alumno = new Alumno(45678987, "Juan Martinez", "Croacia 1230", asignaturasCursadas);
		
		
		alumno.setCarrera(c);
		System.out.println("-------------------------");
		System.out.println("Datos del Alumno:");
		System.out.println("Nombre: " + alumno.getNombre());
		System.out.println("DNI: " + alumno.getDni());
		System.out.println("Direccion: " + alumno.getDireccion() );
		System.out.println("Asignaturas cursadas: " + alumno.getAsignaturasCursadas());
		System.out.println("-------------------------");
		
		Date d= new Date(2020, 06, 9);
		Tramite t = new Tramite(5695221, d, alumno );
		System.out.println("-------------------------");
		System.out.println("Datos del Recibo:");
		System.out.println("Numero de tramite: " + t.getID() );
		System.out.println("Fecha: " + t.getFecha());
		System.out.println("Nombre del alumno: " + alumno.getNombre());
		System.out.println("DNI: " + alumno.getDni());
		System.out.println("-------------------------");
	}
}
