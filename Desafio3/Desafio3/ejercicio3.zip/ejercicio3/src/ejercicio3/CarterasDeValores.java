package ejercicio3;

public class CarterasDeValores {
	
	private double valoresAsociados;
	private String nombreDelValor;
	private Integer numerosDeTitulos;
	private double precioCotizacion;
	public CarterasDeValores(double valoresAsociados, String nombreDelValor, Integer numerosDeTitulos) {
		super();
		this.valoresAsociados = valoresAsociados;
		this.nombreDelValor = nombreDelValor;
		this.numerosDeTitulos = numerosDeTitulos;
		this.precioCotizacion = precioCotizacion;
	}
	public double getValoresAsociados() {
		return valoresAsociados;
	}
	public void setValoresAsociados(double valoresAsociados) {
		this.valoresAsociados = valoresAsociados;
	}
	public String getNombreDelValor() {
		return nombreDelValor;
	}
	public void setNombreDelValor(String nombreDelValor) {
		this.nombreDelValor = nombreDelValor;
	}
	public Integer getNumerosDeTitulos() {
		return numerosDeTitulos;
	}
	public void setNumerosDeTitulos(Integer numerosDeTitulos) {
		this.numerosDeTitulos = numerosDeTitulos;
	}
	public double getPrecioCotizacion() {
		return precioCotizacion;
	}
	public void setPrecioCotizacion(double precioCotizacion) {
		this.precioCotizacion = precioCotizacion;
	}
	

}
