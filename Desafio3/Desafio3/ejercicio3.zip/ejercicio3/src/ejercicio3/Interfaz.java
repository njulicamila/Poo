package ejercicio3;

import java.util.Date;

public class Interfaz {
	
	public static void main(String[] args) {
		
		Cliente c= new Cliente(9489327, "Juan Martinez", "Polonia 5678", 1132654988);
		
		System.out.println("-------------------------");
		System.out.println("Datos del Cliente:");
		System.out.println("Nombre: " + c.getNombre());
		System.out.println("DNI: " + c.getDni());
		System.out.println("Direccion: " + c.getDireccion() );
		System.out.println("Telefono: " + c.getTelefono());
		System.out.println("-------------------------");
		Date d= new Date(2020, 06, 9);
		Cuenta cuenta = new Cuenta(65984658, d, "Caja de ahorro", c);
		cuenta.setSueldo(400000);
		
		System.out.println("-------------------------");
		System.out.println("Datos de la Cuenta:");
		System.out.println("Numero: " + cuenta.getID());
		System.out.println("Fecha: " + cuenta.getFecha());
		System.out.println("Tipo de interes: " + cuenta.getTipoDeInteres() );
		System.out.println("Cliente: " + cuenta.getCliente());
		System.out.println("-------------------------");
		
        Cliente c2= new Cliente(5615218, "Juana Perez", "Matheu 378", 1198643125);
		
		System.out.println("-------------------------");
		System.out.println("Datos del Cliente:");
		System.out.println("Nombre: " + c2.getNombre());
		System.out.println("DNI: " + c2.getDni());
		System.out.println("Direccion: " + c2.getDireccion() );
		System.out.println("Telefono: " + c2.getTelefono());
		System.out.println("-------------------------");
		
		FondoDeInversion fi= new FondoDeInversion(c2.getNombre(), true, d,d);
		fi.setImporte(350000);
		System.out.println("-------------------------");
		System.out.println("Datos del fondo de inversion:");
		System.out.println("Nombre: " + fi.getNombre());
		System.out.println("Importe: " + fi.getImporte());
		System.out.println("Fecha de Apertura: " + fi.getfApertura() );
		System.out.println("Fecha de Vencimiento: " + fi.getfVencimiento());
		System.out.println("-------------------------");
		
		 Cliente c3= new Cliente(65987465, "Pedro Molina", "Castelli 890", 1198643125);
		 
		 CarterasDeValores cv= new CarterasDeValores(35464, "nombre de valor",  5680240);
			
		cv.setPrecioCotizacion(2546.50);
		System.out.println("-------------------------");
		System.out.println("Datos de la cartera de valores:");
		System.out.println("Numero del valor: " + cv.getValoresAsociados());
		System.out.println("Nombre de valor: " + cv.getNombreDelValor());
		System.out.println("Numero titulo: " + cv.getNumerosDeTitulos());
		System.out.println("Precio de cotizacion: " + cv.getPrecioCotizacion());
		System.out.println("-------------------------");
		
		 Cliente c4= new Cliente(65987465, "Pedro Molina", "Castelli 890", 1198643125);
		 TarjetaDeCredito tc= new TarjetaDeCredito(c4.getNombre(), 234567788, "06/07", 12658452);
		 System.out.println("-------------------------");
			System.out.println("Datos de Tarjeta de credito:");
			System.out.println("Titular: " + tc.getTitular());
			System.out.println("Numero: " + tc.getID());
			System.out.println("Fecha vencimiento: " + tc.getFvencimiento());
			System.out.println("Codigo: " + tc.getCodigo());
			System.out.println("-------------------------");
	}

}
