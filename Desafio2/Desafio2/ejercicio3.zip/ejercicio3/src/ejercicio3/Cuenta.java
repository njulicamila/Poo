package ejercicio3;

import java.util.Date;

public class Cuenta {
	private Integer ID;
	private Date fecha;
	private double sueldo;
	private String tipoDeInteres;
    private Cliente cliente;
    
    
	public Cuenta() {
		super();
	}
	public Cuenta(Integer iD, Date fecha, String tipoDeInteres, Cliente cliente) {
		super();
		ID = iD;
		this.fecha = fecha;
		this.tipoDeInteres = tipoDeInteres;
		this.cliente = cliente;
	}
	public Integer getID() {
		return ID;
	}
	public void setID(Integer iD) {
		ID = iD;
	}
	public Date getFecha() {
		return fecha;
	}
	public void setFecha(Date fecha) {
		this.fecha = fecha;
	}
	public double getSueldo() {
		return sueldo;
	}
	public void setSueldo(double sueldo) {
		this.sueldo = sueldo;
	}
	public String getTipoDeInteres() {
		return tipoDeInteres;
	}
	public void setTipoDeInteres(String tipoDeInteres) {
		this.tipoDeInteres = tipoDeInteres;
	}
	public Cliente getCliente() {
		return cliente;
	}
	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}
    
    
}
