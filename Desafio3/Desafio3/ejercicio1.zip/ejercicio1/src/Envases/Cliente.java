package Envases;

public class Cliente {
	
	
	
	public void devolverElemento() {
		//devuelve envases, botllas, latas.
	}

}
