package Envases;

public class Recibo {

	private Double valor;
	private int cantElementos;
	private double total;
	private String tipo;
	public Double getValor() {
		return valor;
	}
	public void setValor(Double valor) {
		this.valor = valor;
	}
	public int getCantElementos() {
		return cantElementos;
	}
	public void setCantElementos(int cantElementos) {
		this.cantElementos = cantElementos;
	}
	public double getTotal() {
		return total;
	}
	public void setTotal(double total) {
		this.total = total;
	}
	public String getTipo() {
		return tipo;
	}
	public void setTipo(String tipo) {
		this.tipo = tipo;
	}
	
	
}
